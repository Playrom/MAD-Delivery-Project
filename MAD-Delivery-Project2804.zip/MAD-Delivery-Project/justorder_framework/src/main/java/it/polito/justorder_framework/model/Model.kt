package it.polito.justorder_framework.model

import java.io.Serializable

open class Model : Serializable{
    open var keyId: String? = null
}