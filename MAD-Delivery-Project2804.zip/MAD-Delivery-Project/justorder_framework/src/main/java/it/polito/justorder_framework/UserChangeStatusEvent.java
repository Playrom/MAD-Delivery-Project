package it.polito.justorder_framework;

public class UserChangeStatusEvent {
}
